const express = require('express');
const router = express.Router();
const matriculaController = require('../controllers/matriculaController');

// Definir rutas
router.post('/', matriculaController.createMatricula);
router.get('/', matriculaController.getAllMatriculas);
router.get('/estudiantes/:id/cursos', matriculaController.getCursosByEstudiante);
router.get('/cursos/:id/estudiantes', matriculaController.getEstudiantesByCurso);

module.exports = router;
