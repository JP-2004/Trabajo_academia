const Matricula = require('../models/matricula');
const Estudiante = require('../models/estudiante');
const Curso = require('../models/curso');

// Crear una nueva matrícula
exports.createMatricula = async (req, res) => {
  try {
    const { estudianteId, cursoId, fecha_matricula } = req.body;

    const matricula = await Matricula.create({ estudianteId, cursoId, fecha_matricula });
    res.status(201).json(matricula);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear la matrícula.' });
  }
};

// Obtener todas las matrículas incluyendo estudiante y curso
exports.getAllMatriculas = async (req, res) => {
  try {
    const matriculas = await Matricula.findAll({
      include: [
        { model: Estudiante },
        { model: Curso }
      ]
    });
    res.json(matriculas);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener las matrículas.' });
  }
};

// Obtener todos los cursos de un estudiante
exports.getCursosByEstudiante = async (req, res) => {
  try {
    const { id } = req.params;
    const estudiante = await Estudiante.findByPk(id, {
      include: {
        model: Curso,
        through: { attributes: [] } // No mostrar datos intermedios
      }
    });

    if (!estudiante) {
      return res.status(404).json({ error: 'Estudiante no encontrado.' });
    }

    res.json(estudiante.Cursos);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener los cursos del estudiante.' });
  }
};

// Obtener todos los estudiantes de un curso
exports.getEstudiantesByCurso = async (req, res) => {
  try {
    const { id } = req.params;
    const curso = await Curso.findByPk(id, {
      include: {
        model: Estudiante,
        through: { attributes: [] }
      }
    });

    if (!curso) {
      return res.status(404).json({ error: 'Curso no encontrado.' });
    }

    res.json(curso.Estudiantes);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener los estudiantes del curso.' });
  }
};
