const Estudiante = require('../models/estudiante');

const getAllEstudiantes = async (req, res) => {
  const estudiantes = await Estudiante.findAll();
  res.json(estudiantes);
};

const getEstudianteById = async (req, res) => {
  const estudiante = await Estudiante.findByPk(req.params.id);
  res.json(estudiante);
};

const createEstudiante = async (req, res) => {
  const estudiante = await Estudiante.create(req.body);
  res.json(estudiante);
};

const updateEstudiante = async (req, res) => {
  await Estudiante.update(req.body, { where: { id: req.params.id } });
  res.json({ mensaje: 'Estudiante actualizado' });
};

const deleteEstudiante = async (req, res) => {
  await Estudiante.destroy({ where: { id: req.params.id } });
  res.json({ mensaje: 'Estudiante eliminado' });
};

module.exports = {
  getAllEstudiantes,
  getEstudianteById,
  createEstudiante,
  updateEstudiante,
  deleteEstudiante
};
