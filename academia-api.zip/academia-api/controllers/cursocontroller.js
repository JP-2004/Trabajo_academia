const Curso = require('../models/curso');

// Obtener todos los cursos
exports.getAllCursos = async (req, res) => {
  try {
    const cursos = await Curso.findAll();
    res.json(cursos);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener cursos.' });
  }
};

// Obtener un curso por ID
exports.getCursoById = async (req, res) => {
  try {
    const { id } = req.params;
    const curso = await Curso.findByPk(id);
    if (!curso) {
      return res.status(404).json({ error: 'Curso no encontrado.' });
    }
    res.json(curso);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener el curso.' });
  }
};

// Crear un nuevo curso
exports.createCurso = async (req, res) => {
  try {
    const { nombre, descripcion, duracion_horas } = req.body;
    const curso = await Curso.create({ nombre, descripcion, duracion_horas });
    res.status(201).json(curso);
  } catch (error) {
    res.status(500).json({ error: 'Error al crear el curso.' });
  }
};

// Actualizar un curso
exports.updateCurso = async (req, res) => {
  try {
    const { id } = req.params;
    const { nombre, descripcion, duracion_horas } = req.body;
    const curso = await Curso.findByPk(id);

    if (!curso) {
      return res.status(404).json({ error: 'Curso no encontrado.' });
    }

    curso.nombre = nombre;
    curso.descripcion = descripcion;
    curso.duracion_horas = duracion_horas;
    await curso.save();

    res.json(curso);
  } catch (error) {
    res.status(500).json({ error: 'Error al actualizar el curso.' });
  }
};

// Eliminar un curso
exports.deleteCurso = async (req, res) => {
  try {
    const { id } = req.params;
    const curso = await Curso.findByPk(id);

    if (!curso) {
      return res.status(404).json({ error: 'Curso no encontrado.' });
    }

    await curso.destroy();
    res.json({ message: 'Curso eliminado correctamente.' });
  } catch (error) {
    res.status(500).json({ error: 'Error al eliminar el curso.' });
  }
};
