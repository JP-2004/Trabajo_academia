const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Estudiante = require('./estudiante');
const Curso = require('./curso');

const Matricula = sequelize.define('Matricula', {
  id: {
    type: DataTypes.UUID,
    defaultValue: DataTypes.UUIDV4,
    primaryKey: true
  },
  estudianteId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: Estudiante,
      key: 'id'
    }
  },
  cursoId: {
    type: DataTypes.UUID,
    allowNull: false,
    references: {
      model: Curso,
      key: 'id'
    }
  },
  fecha_matricula: {
    type: DataTypes.DATEONLY,
    allowNull: false
  }
}, {
  tableName: 'Matricula',
  timestamps: false
});

// Relaciones
Estudiante.belongsToMany(Curso, { through: Matricula, foreignKey: 'estudianteId' });
Curso.belongsToMany(Estudiante, { through: Matricula, foreignKey: 'cursoId' });

module.exports = Matricula;
